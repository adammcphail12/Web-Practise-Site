<div class ="box footer">
            &copy; A. M. 2022 
        </div> <!-- Footer Ends -->

    </div> <!-- Wrapper Ends -->
</body>