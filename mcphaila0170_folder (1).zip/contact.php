<?php include("head_nav.php"); ?>

        <div class ="box main">
            <h2> About me </h2>
            <p> My name is Adam McPhail and this is my Web Design Assesment </p>
            <p> I enjoy meals like my mums Pork meatballs with Peanut Sauce. </p>
            <p> The meals on this website have been reviewd by Ms Gottschalk my COM101 teacher </p>

        <iframe src="https://docs.google.com/forms/d/e/1FAIpQLSfXsKgc6-v4d9J1YGcy8JDdEXlucLki4B8hvg5ztSmNT0PgfA/viewform?embedded=true" width="640" height="676" frameborder="0" marginheight="0" marginwidth="0">Loading…</iframe>
        </div> <!-- Main Ends -->

        <div class ="box side">
            <h2>Navigation</h2> 
            <a href="index.php">Home</a>  <br><br>
            <a href="breakfast.php">Breakfast</a>  <br><br>
            <a href="lunch.php">Lunch</a> <br><br>
            <a href="dinner.php">Dinner</a>  <br><br>
            <a href="contact.php">Contact</a> <br><br>

        </div> <!-- Side Ends -->

<?php include("footer.php"); ?>