<?php include("head_nav.php"); ?>

        <div class ="box main">
            <h2>Non Fiction</h2>
            <p>Title: <span class = "subheading">Don't make me think</span></p>

            <p>Genre (Text Type): <span class="subheading">Non Fiction - Usability</span></p>

            <p>Authors: <span class="subheading">Steve Krug</span></p>

            <p>Rating:<span class="subheading">&#9733;&#9733;&#9733;&#9733;&#9733;</span></p>

            <p>Review / Response</p>

            <p>
                The book is aimed at software developers and designers and can be read in roughly 2 hours (the author argues that anything longer would be less useful). The book’s main theme is ‘Don’t make me think’ ie: usable interfaces are self-explanatory. Put another way, users should not need to expend any effort thinking about what to do - it should be obvious.

                One of my favourite parts of the book is the ‘facts of life’ - they are a quick summary of how users operate that might not be obvious to designers. Said ‘facts of life’ are the result Krug’s observations on how people actually use his client’s interfaces. They include the following ideas...

                Users scan for information rather than reading everything on a page
                Users 'suffice' (ie: they will choose the first reasonable option rather than taking the time to look for the best possible choice).
                Users often 'muddle through' and use outcomes in ways that are very different from what the designer intended.

                Whilst the chapter on mobile design is outdated (and of limited use), this book is a brilliant resource, as it is quick to read, easy to understand and written for busy people with limited time.</p>
        


        </div> <!-- Main Ends -->

        <div class ="box side">
            <div class = "center-image">
                <img class = "img-circle" src="Images\dont think.png" alt="">
                <p>“Don’t Make me Think” is a fun, practical book that describes the need for frequent, informal testing to ensure that an interface (such as a website) is easy to use. The book’s informal style is appealing and whilst some of the material is out of date, most of the information easy to understand and implement.</p>

            </div> <!-- Center Image ends -->
        </div> <!-- Side Ends -->

<?php include("footer.php"); ?>