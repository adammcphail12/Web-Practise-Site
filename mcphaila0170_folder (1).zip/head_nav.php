<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name = "description" content= "add content">
    <meta name = "keywords" content = "add keywords seperate with commas">
    <meta name = "author" content = "add your name">
    <meta name = "viewport" content = "width=device-width, initial-scale=1.0">

    <title>Book Reviews</title>

    <link rel = "stylesheet" href = "css/bookstyle.css">


    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Raleway:ital,wght@0,400;1,600&display=swap" rel="stylesheet">
    
</head>
<body>
    <div class="wrapper">
        <div class ="box logo">
            <!--<img src="Images/logo.png" width="300" height="199" alt="Book fan Logo" /> -->
        </div> <!-- Logo Ends -->

        <div class ="box banner">
            <h2>Adams Book Reviews</h2>
        </div> <!-- Banner Ends -->

        <div class ="box nav">
            <a href="index.php">Home</a> | 
            <a href="scifi.php">Sci Fi</a> |
            <a href="humour.php">Humour</a> |
            <a href="nonfiction.php">Non Fiction</a> |
            <a href="contact.php">Contact</a> 
        </div> <!-- Nav Ends -->