<?php include("head_nav.php"); ?>

        <div class ="box main">
            <h2> Breakfast </h2>
            <p>Meal: <span class = "subheading">Smoked Salmon Omelet</span></p>

            <p>Location: <span class="subheading">Home</span></p>

            <p>Rating:<span class="subheading">&#9733;&#9733;&#9733;&#9733;&#9733;</span></p>

            <p>Review / Response</p>
            <p>This is a Sunday morning event and is one of my favourite foods. The omelet is made
                with one egg and filled with a generous
                serve of smoked salmon and cream
                cheese. In summer, the addition of fresh
                chives makes this meal extra-special. It is
                normally served with two slices of whole
                meal toast and butter.
            </p>

            <br><br>

            <img src = "Images/omelette.png" width = "640" height = "427">

            <br><br>

            <p>Meal: <span class = "subheading">French Toast</span></p>

            <p>Location: <span class="subheading">Home</span></p>

            <p>Rating:<span class="subheading">&#9733;&#9733;&#9733;&#9733;&#9733;</span></p>

            <p>Review / Response</p>
            <p>
                This dish is vegetarian.
                The trick to this one is to use homemade
                raison bread (instead of shop-bought white
                / brown bread) and be generous with the
                amount of syrup / cinnamon and sugar
                added on the top. Provided the egg is
                properly cooked this is the ultimate in
                decadent breakfasts. It is a once a year
                treat that is totally worth every calorie.
            </p>
            <br><br>

            <img src = "Images/omelette.png" width = "640" height = "427">

            <br><br>



        </div> <!-- Main Ends -->

        <div class ="box side" id = "sideText">
            
        
            <h2>Navigation</h2>

            <div class = "navBox"> <!-- Home Div Ends -->
                <a href="index.php">
                Home
                <br><br>
                <img src = "Images/home.png" width = "50" height = "47">
                </a> 
            </div> <!-- Home Div Ends -->
            <br><br>

            <div class = "navBox"> <!-- Breakfast Div-->
                <a href="breakfast.php">
                Breakfast
                <br><br>
                <img src = "Images/egg.png" width = "40" height = "60">
                </a> 
            </div> <!-- Breakfast Div Ends -->

            <br><br>

            <div class = "navBox"> <!-- Lunch Div -->
                <a href="lunch.php">
                Lunch
                <br><br>
                <img src = "Images/sushi.png" width = "50" height = "43">
                </a> 
            </div> <!-- Lunch div ends -->
            <br><br>

            <div class = "navBox"> <!-- Dinner Div -->
                <a href="dinner.php">
                Dinner
                <br><br>
                <img src = "Images/kebab.png" width = "50" height = "71.5">
                </a>  
            </div><!-- Dinner Div Ends -->
            <br><br>

            <div class = "navBox"> <!-- Contact Div -->
                <a href="contact.php">
                Contact
                <br><br>
                <img src = "Images/phone.png" width = "50" height = "67.5">
                </a>
            </div>    <!-- Contact Div Ends -->
            
            <br><br>
            
            
            </ul>
        </div> <!-- Side Ends -->


<?php include("footer.php"); ?>